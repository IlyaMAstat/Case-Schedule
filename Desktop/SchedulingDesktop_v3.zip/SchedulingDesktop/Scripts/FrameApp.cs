﻿using System.Windows.Controls;

namespace SchedulingDesktop.Scripts
{
    class FrameApp
    {
        public static Frame frmObj;
    }
}

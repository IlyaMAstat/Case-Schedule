﻿using SchedulingDesktop.Scripts;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace SchedulingDesktop.Pages
{
    /// <summary>
    /// Логика взаимодействия для pSchedule.xaml
    /// </summary>
    public partial class pSchedule : Page
    {
        public static ObservableCollection<TableHelp> tblHelp { get; set; }
        public static int dayWeek { get; set; }
        public pSchedule()
        {
            InitializeComponent();
            //Заполнение всп Класса
            tblHelp = new ObservableCollection<TableHelp>();
            foreach (ClassView cv in ConnectHelper.entObj.ClassView.ToList())
            {
                tblHelp.Add(
                    new TableHelp(
                         cv,
                           ConnectHelper.entObj.TeachDisc.
                           Where(t =>
                          cv.ClassID >= t.ClassFrom && cv.ClassID <= t.ClassTo).ToList()
                        ));
            }

            //Создание сетки расписания
            foreach (TableHelp help in tblHelp)
            {
                Grid grid = GetGrid();
                //Создание строки заголовков
                if (help == tblHelp[0])
                {
                    Grid grid1 = GetGrid();
                    TextBlock tbHeadClass = new TextBlock
                    {
                        Text = "Классы",
                        TextAlignment = TextAlignment.Center
                    };
                    grid1.Children.Add(tbHeadClass);
                    Grid.SetColumn(tbHeadClass, 0);
                    for (int i = 1; i <= 7; i++)
                    {
                        TextBlock tbHeadNum = new TextBlock
                        {
                            Text = i.ToString(),
                            TextAlignment = TextAlignment.Center
                        };
                        grid1.Children.Add(tbHeadNum);
                        Grid.SetColumn(tbHeadNum, i);
                    }
                    spSch.Children.Add(grid1);
                }

                //Название класса 1 столб
                TextBlock tb = new TextBlock
                {
                    Text = help.classView.Title,
                    TextAlignment = TextAlignment.Center,
                    Margin = new Thickness(5),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };
                grid.Children.Add(tb);
                Grid.SetColumn(tb, 0);

                //Создание 2-8 столбцов
                for (int i = 1; i <= 7; i++)
                {
                    //Условие масимального количества уроков для класса
                    bool t = true;
                    if (i > help.classView.MaxLessons) t = false;

                    //Выбор Дисциплины
                    ComboBox cbd = new ComboBox
                    {
                        IsEnabled = t,
                        ItemsSource = ConnectHelper.entObj.Discipline.Where(d => help.classView.ClassID >= d.ClassFrom && help.classView.ClassID <= d.ClassTo).Distinct().ToList(),
                        DisplayMemberPath = "Title",
                        MinWidth = 150,
                        MinHeight = 25,
                        Margin = new Thickness(3)
                    };
                    cbd.SelectionChanged += cbDiscipline_SelectionChanged;

                    //Выбор Учителя
                    ComboBox cbt = new ComboBox
                    {
                        IsEnabled = false,
                        Visibility = Visibility.Collapsed,
                        DisplayMemberPath = "FIO",
                        MinWidth = 150,
                        MinHeight = 25,
                        Margin = new Thickness(3)
                    };
                    cbt.SelectionChanged += cbTeacher_SelectionChanged;

                    //Создание панели которая содержит выбор кабинета и удаление урока у класса
                    ComboBox cbc = new ComboBox
                    {
                        MinWidth = 120,
                        MinHeight = 25,
                        HorizontalAlignment = HorizontalAlignment.Left,
                        Text = "Кабинеты",
                        IsEditable = true,
                        Margin = new Thickness(3),
                        IsEnabled = false,
                        Visibility = Visibility.Hidden,
                        DisplayMemberPath = "Num"
                    };
                    cbc.SelectionChanged += cbTeacher_SelectionChanged;

                    Button btnDel = new Button
                    {
                        HorizontalAlignment = HorizontalAlignment.Right,
                        Content = "❌",
                        Foreground = Brushes.Red,
                        Margin = new Thickness(3)
                    };
                    btnDel.Click += btnDel_Click;

                    DockPanel stackPanel = new DockPanel
                    {
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        Margin = new Thickness(3),
                        Children =
                        {
                            cbc,
                           btnDel
                        }
                    };

                    //Создание панели для выбора учителя предмета и кабинета.
                    StackPanel sp = new StackPanel
                    {
                        Orientation = Orientation.Vertical,
                        Margin = new Thickness(5),
                        Children = { stackPanel, cbd, cbt }
                    };
                    grid.Children.Add(sp);
                    Grid.SetColumn(sp, i);
                    //Заполнение данными если есть
                    Schedule sch = ConnectHelper.entObj.Schedule.Where
                        (s => s.Num == i &&
                        s.ClassID == help.classView.Id&&
                        s.WeekId==dayWeek).FirstOrDefault();
                    if (sch != null)
                    {
                        clasReserv = help.classView.Title;
                        ColumnReserv = i;
                        cbd.SelectedItem = ConnectHelper.entObj.Discipline.Where(te => te.Id == sch.TeacherDiscipline.DisciplineID).FirstOrDefault();
                        cbt.SelectedItem = ConnectHelper.entObj.TeachDisc.Where(te => te.Id == sch.TeacherDisciplineID).FirstOrDefault();
                        ColumnReserv = i;
                        cbc.SelectedItem = ConnectHelper.entObj.Cabinet.Where(c => c.Num == sch.CabinetNum).FirstOrDefault();
                    }
                }

                //Вспом элемент для запоминания класса на этой строке
                ComboBoxItem cbid = new ComboBoxItem
                {
                    IsEnabled = false,
                    Visibility = Visibility.Collapsed,
                    Content = help.classView
                };
                grid.Children.Add(cbid);
                spSch.Children.Add(grid);
            }
            Update();

        }

        //Отображение невозможного расписания
        public void Update()
        {
            //   if (start == 0) return;
            //столбцы
            for (int i = 1; i <= 7; i++)
            {
                List < Cabinet >  cabinets= new List<Cabinet>();
                List<TeachDisc> teachers = new List<TeachDisc>();
                for (int j = 1; j <= ConnectHelper.entObj.Class.Count(); j++)//строки
                {
                    Grid grid = spSch.Children[j] as Grid;
                    StackPanel sp = grid.Children[i] as StackPanel;
                    ComboBox cbt = sp.Children[2] as ComboBox;
                    TeachDisc td = cbt.SelectedItem as TeachDisc;
                    ComboBox cbc = (sp.Children[0] as DockPanel).Children[0] as ComboBox;
                    Cabinet cab = cbc.SelectedItem as Cabinet;
                    if (cab != null)
                        cabinets.Add(cab);
                    if (td != null)
                        teachers.Add(td);
                }
                    for (int j = 1; j <= ConnectHelper.entObj.Class.Count(); j++)//строки
                {
                    Grid grid = spSch.Children[j] as Grid;
                    StackPanel sp = grid.Children[i] as StackPanel;
                    ComboBox cbt = sp.Children[2] as ComboBox;
                    TeachDisc td = cbt.SelectedItem as TeachDisc;
                    ComboBox cbc = (sp.Children[0] as DockPanel).Children[0] as ComboBox;
                    Cabinet cab = cbc.SelectedItem as Cabinet;
                    sp.Background = Brushes.Transparent;
                    sp.ToolTip = null;
                    if (td != null && teachers.Where(t=>t.TeacherID==td.TeacherID).Count() > 1)
                    {
                        sp.Background = Brushes.LightCoral;
                        sp.ToolTip = "Учитель не может находится на двух уроках одновременно!";
                    }
                    if (cab != null &&cabinets.Where(c=>c.Num==cab.Num).Count() > 1)
                    {
                        sp.Background = Brushes.LightCoral;
                        sp.ToolTip = "В кабинете не может заниматься больше одного класса";
                    }
                }


            }
        }


        //Создание строки рассписания
        private static Grid GetGrid()
        {
            Grid grid = new Grid { Margin = new Thickness(5), ShowGridLines = true, MinHeight = 30, MinWidth = 400 };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(100) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 150 });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 150 });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 150 });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 150 });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 150 });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 150 });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 150 });
            return grid;
        }

        int ColumnReserv = 0;

        //Сохранение при доступности
        private void cbTeacher_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ColumnReserv != 0)
            {
                ColumnReserv = 0; return;
            }
            StackPanel sp = new StackPanel();
            if ((sender as ComboBox).Parent is DockPanel)
                sp = ((sender as ComboBox).Parent as DockPanel).Parent as StackPanel;
            else
                sp = (sender as ComboBox).Parent as StackPanel;
            ComboBox cbt = sp.Children[2] as ComboBox;
            ComboBox cbd = sp.Children[1] as ComboBox;
            ComboBox cbc = (sp.Children[0] as DockPanel).Children[0] as ComboBox;
            Update();
            if (cbt.SelectedItem == null) { return; }
            if (cbc.SelectedItem == null) { cbc.Text = "";  return; }
            
            int column = (sp.Parent as Grid).Children.IndexOf(sp);
            ClassView cv = ((sp.Parent as Grid).Children[(sp.Parent as Grid).Children.Count - 1] as ComboBoxItem).Content as ClassView;
            int lesson = int.Parse(((spSch.Children[0] as Grid).Children[column] as TextBlock).Text);
            TeachDisc teacher = cbt.SelectedItem as TeachDisc;
            Discipline d = cbd.SelectedItem as Discipline;
            TeacherDiscipline td = ConnectHelper.entObj.TeacherDiscipline.FirstOrDefault(ted => ted.DisciplineID == d.Id && ted.TeacherID == teacher.TeacherID);
            Schedule sch = ConnectHelper.entObj.Schedule.Where
                (s => s.Num == lesson &&
                s.ClassID == cv.Id &&
                        s.WeekId == dayWeek).FirstOrDefault();
            if (sch == null)
            {
                sch = new Schedule
                {
                    Num = lesson,
                    TeacherDisciplineID = td.Id,
                    ClassID = cv.Id,
                    WeekId = dayWeek,
                    CabinetNum = (cbc.SelectedItem as Cabinet).Num
                };
                ConnectHelper.entObj.Schedule.Add(sch);

                // MessageBox.Show("Null");
            }
            else
            {
                sch.Num = lesson;
                sch.TeacherDisciplineID = td.Id;
                sch.ClassID = cv.Id;
                sch.WeekId = dayWeek;
                sch.CabinetNum = (cbc.SelectedItem as Cabinet).Num;
                // MessageBox.Show("NotNull");
            }
            ConnectHelper.entObj.SaveChanges();
            Update();
        }
        string clasReserv = "";
        private void cbDiscipline_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox cbd = sender as ComboBox;
            StackPanel sp = cbd.Parent as StackPanel;
            ComboBox cbt = sp.Children[2] as ComboBox;
            ComboBox cbc = (sp.Children[0] as DockPanel).Children[0] as ComboBox;
            string clas = "";
            if ((sp.Parent as Grid) == null)
                clas = clasReserv;
            else
                clas = ((sp.Parent as Grid).Children[0] as TextBlock).Text;

            if (cbd.SelectedItem == null)
            {
                cbt.Visibility = Visibility.Collapsed;
                cbt.IsEnabled = false;
                cbc.Visibility = Visibility.Collapsed;
                cbc.IsEnabled = false;
            }
            else
            {
                Discipline disc = cbd.SelectedItem as Discipline;
                if (clas.Length == 3 || int.Parse(clas[0].ToString()) >= 5)
                {
                    cbt.ItemsSource = ConnectHelper.entObj.TeachDisc.Where(td => td.DisciplineID == disc.Id && !td.PrimTeach).OrderByDescending(td => td.PrimTeach).ToList();
                }
                else
                {
                    cbt.ItemsSource = ConnectHelper.entObj.TeachDisc.Where(td => td.DisciplineID == disc.Id).OrderByDescending(td => td.PrimTeach).ToList();
                }
                switch (disc.Title)
                {
                    case "Технология":
                        cbc.ItemsSource = ConnectHelper.entObj.Cabinet.Where(c => c.Trud).ToList();
                        break;

                    case "Физкультура":
                        cbc.ItemsSource = ConnectHelper.entObj.Cabinet.Where(c => c.Sport).ToList();
                        break;

                    case "Информатика":
                        cbc.ItemsSource = ConnectHelper.entObj.Cabinet.Where(c => c.Info).ToList();
                        break;

                    default:
                        if ((disc.Prim && clas.Length == 2 && int.Parse(clas[0].ToString()) < 5) || clas.Length == 2 && int.Parse(clas[0].ToString()) < 5)
                            cbc.ItemsSource = ConnectHelper.entObj.Cabinet.Where(c => c.Prim).ToList();
                        else 
                            cbc.ItemsSource = ConnectHelper.entObj.Cabinet.Where(c => !c.Info && !c.Prim && !c.Sport && !c.Trud).ToList();
                        break;
                }

                cbt.Visibility = Visibility.Visible;
                cbt.IsEnabled = true;
                cbc.Visibility = Visibility.Visible;
                cbc.IsEnabled = true;

            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
        private void btnDel_Click(object sender, RoutedEventArgs e)
        {
            StackPanel sp = ((sender as Button).Parent as DockPanel).Parent as StackPanel;
            ComboBox cbt = sp.Children[2] as ComboBox;
            ComboBox cbd = sp.Children[1] as ComboBox;
            ComboBox cbc = (sp.Children[0] as DockPanel).Children[0] as ComboBox;
            int column = (sp.Parent as Grid).Children.IndexOf(sp);
            ClassView cv = ((sp.Parent as Grid).Children[(sp.Parent as Grid).Children.Count - 1] as ComboBoxItem).Content as ClassView;
            int lesson = int.Parse(((spSch.Children[0] as Grid).Children[column] as TextBlock).Text);
            Schedule sch = ConnectHelper.entObj.Schedule.Where
    (s => s.Num == lesson &&
    s.ClassID == cv.Id &&
            s.WeekId == dayWeek).FirstOrDefault();
            if (sch == null)
            {
                cbt.SelectedItem = null;
                cbc.SelectedItem = null;
                cbc.Text = null;
                cbd.SelectedItem = null;
            }
            else
            {
                ConnectHelper.entObj.Schedule.Remove(sch);
                cbt.SelectedItem = null;
                cbc.SelectedItem = null;
                cbc.Text = null;
                cbd.SelectedItem = null;
            }
            ConnectHelper.entObj.SaveChanges();
            Update();
        }
    }

    public class TableHelp
    {
        public List<TeachDisc> teachDisc { get; set; }

        public ClassView classView { get; set; }


        public TableHelp(ClassView cv, List<TeachDisc> td)
        {
            teachDisc = td;
            classView = cv;

        }
    }
}

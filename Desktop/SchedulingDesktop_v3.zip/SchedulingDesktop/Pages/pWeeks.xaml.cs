﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
using SchedulingDesktop.Scripts;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SchedulingDesktop.Pages
{
    /// <summary>
    /// Логика взаимодействия для pWeeks.xaml
    /// </summary>
    public partial class pWeeks : Page
    {
        public pWeeks()
        {
            InitializeComponent();
        }

        private void btnWeek_Click(object sender, RoutedEventArgs e)
        {
          
            pSchedule.dayWeek = getWeekNum((sender as Button).Content.ToString());
            FrameApp.frmObj.Navigate(new pSchedule());
        }

        public  int getWeekNum(string week)
        {
            switch (week)
            {
                case "Понедельник":
                    return 1;

                case "Вторник":
                    return 2;

                case "Среда":
                    return 3;

                case "Четверг":
                    return 4;

                case "Пятница":
                    return 5;
                default:
                    return 0;
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            for (int w = 1; w < 6; w++)//week
            {
                for (int n = 1; n < 8; n++)//LessonNum
                {
                    List<int> teachers = ConnectHelper.entObj.Schedule.Where(s => s.WeekId == w && s.Num == n).Select(s => s.TeacherDiscipline.TeacherID).ToList();
                    List<int?> cabinets = ConnectHelper.entObj.Schedule.Where(s => s.WeekId == w && s.Num == n).Select(s => s.CabinetNum).ToList();
                    List<int> teachers2 = teachers.Distinct().ToList();
                    List<int?> cabinets2 = cabinets.Distinct().ToList();
                    if (cabinets.Count > teachers2.Count() || teachers.Count > cabinets2.Count())
                    {
                        (gWeek.Children[w - 1] as Rectangle).Visibility = Visibility.Visible;
                        (gWeek.Children[w - 1] as Rectangle).ToolTip = "Имеется конфликты с учителями или кабинетами";
                        (gWeek.Children[w + 4] as Button).ToolTip = "Имеется конфликты с учителями или кабинетами";
                        break;
                    }
                    else
                    {
                        (gWeek.Children[w - 1] as Rectangle).Visibility = Visibility.Hidden;
                        (gWeek.Children[w - 1] as Rectangle).ToolTip = null;
                        (gWeek.Children[w + 4] as Button).ToolTip = null;
                    }
                }
            }
            if (ConnectHelper.entObj.WarningLessons.Count() > 0)
                tbSvod.Text = "В этих классах необхадимо убрать указанное количество уроков: ";
            else
                tbSvod.Text = "";
            foreach (WarningLessons wl in ConnectHelper.entObj.WarningLessons)
            {
                tbSvod.Text += $"В {wl.Title} - {wl.CountLessons-wl.MaxHours} уроков (назначено {wl.CountLessons} из {wl.MaxHours}) ";
            }
        }

        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Schedule.xlsx"))
            {
                try
                {
                    FileStream fs = File.Open(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Schedule.xlsx", FileMode.Open);
                    fs.Close();
                }
                catch
                {
                    MessageBox.Show("Файл Schedule.xlsx запущен на компьютере. Пожалуйста выключите его",
                        "Файл недоступен",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);

                    return;
                }
            }
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            ExcelPackage package = new ExcelPackage();

            ExcelWorksheet sheet = package.Workbook.Worksheets.Add("Расписание");
            double column = 5;
            List<Class> cls = ConnectHelper.entObj.Class.ToList();
            List<ScheduleView> lessons = ConnectHelper.entObj.ScheduleView.ToList();

            int addRow = (int)Math.Floor(ConnectHelper.entObj.Class.Count()/column)*9;

            int countcol =1+ (int)column * 4;
            sheet.Columns[1].Width = 1;
            sheet.Columns[1,countcol].Style.Font.SetFromFont(new System.Drawing.Font( "Segoe UI",12));
            foreach (Week w in ConnectHelper.entObj.Week)
            {
                int row = (w.Id - 1) * (10+addRow+1)+1;
                int backrow = row;
                sheet.Cells[row+1, 2, row + 1, countcol].Merge = true;
                sheet.Cells[row + 1, 2, row + 1, countcol].Style.Font.Bold = true;
                sheet.Cells[row + 1, 2, row + 1, countcol].Style.Font.SetFromFont(new System.Drawing.Font("Segoe UI", 16));
                sheet.Cells[row + 1, 2, row + 1, countcol].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                sheet.Cells[row + 1, 2, row + 1, countcol].Value = w.Title;
                int columnstart = 2;
                for (int c = 0; c < cls.Count(); c++,columnstart+=4)
                {
                    
                    if (columnstart >= countcol)
                    {
                        columnstart = 2;
                        row += 9;
                    }
                    sheet.Columns[columnstart].Width = 6;
                    sheet.Columns[columnstart + 1].Width = 20;
                    sheet.Columns[columnstart + 2].Width = 20;

                    string classnum = cls[c].Title;
                    sheet.Cells[row + 2, columnstart, row + 2, columnstart + 3].Merge = true;
                    sheet.Cells[row + 2, columnstart, row + 2, columnstart + 3].Value = classnum;
                    sheet.Cells[row + 2, columnstart, row + 2, columnstart + 3].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    sheet.Cells[row + 2, columnstart, row + 2, columnstart + 3].Style.Font.SetFromFont(new System.Drawing.Font("Segoe UI", 14));

                    sheet.Cells[row + 3, columnstart].Value = "Урок";
                    sheet.Cells[row + 3, columnstart + 1].Value = "Предмет";
                    sheet.Cells[row + 3, columnstart + 2].Value = "Учитель";
                    sheet.Cells[row + 3, columnstart + 3].Value = "Кабинет";
                    sheet.Cells[row + 3, columnstart].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                    sheet.Cells[row + 3, columnstart + 1].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                    sheet.Cells[row + 3, columnstart + 2].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                    sheet.Cells[row + 3, columnstart + 3].Style.Border.BorderAround(ExcelBorderStyle.Thin);

                    for (int r = 1; r <= 7; r++)
                    {

                        ScheduleView lesson = ConnectHelper.entObj.ScheduleView.Where(s => s.LessonNum == r && s.WeekId == w.Id&& s.ClassTitle== classnum).FirstOrDefault();
                        sheet.Cells[row + r + 3, columnstart].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                        sheet.Cells[row + r + 3, columnstart + 1].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                        sheet.Cells[row + r + 3, columnstart + 2].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                        sheet.Cells[row + r + 3, columnstart + 3].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                        sheet.Cells[row + r + 3, columnstart].Value =  r;
                        if (lesson == null) continue;
                        sheet.Cells[row + r + 3, columnstart + 1].Value = lesson.Title;
                        sheet.Cells[row + r + 3, columnstart + 2].Value = lesson.FIO;
                        sheet.Cells[row + r + 3, columnstart+3].Value = lesson.CabinetNum;
                    }
                    sheet.Cells[row + 2, columnstart, row + 10, columnstart + 3].Style.Border.BorderAround(ExcelBorderStyle.Medium);
                }
                sheet.Cells[backrow + 1, 2, backrow + 10 + addRow, countcol ].Style.Border.BorderAround(ExcelBorderStyle.Thick);
                ExcelWorksheet nsheet = package.Workbook.Worksheets.Add(w.Title);
                   
                sheet.Cells[backrow + 1, 2, backrow + 10 + addRow, countcol].Copy(nsheet.Cells[2,2]);
                nsheet.Columns[1].Width = 1;
                for (int i = 3; i < 50; i += 4)
                {
                    nsheet.Columns[i].Width = 20;
                    nsheet.Columns[i+1].Width = 20;
                }
            }
            File.WriteAllBytes(Environment.GetFolderPath(Environment.SpecialFolder.Personal)+"\\Schedule.xlsx",package.GetAsByteArray());

            Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.Personal)+"\\Schedule.xlsx");
        }
    }
}

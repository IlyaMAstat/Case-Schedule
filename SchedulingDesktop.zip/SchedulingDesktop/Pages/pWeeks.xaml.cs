﻿using SchedulingDesktop.Scripts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SchedulingDesktop.Pages
{
    /// <summary>
    /// Логика взаимодействия для pWeeks.xaml
    /// </summary>
    public partial class pWeeks : Page
    {
        public pWeeks()
        {
            InitializeComponent();
        }

        private void btnWeek_Click(object sender, RoutedEventArgs e)
        {
            switch ((sender as Button).Content.ToString())
            {
                case "Понедельник":
                    pSchedule.dayWeek = 1;
                    break;

                case "Вторник":
                    pSchedule.dayWeek = 2;
                    break;

                case "Среда":
                    pSchedule.dayWeek = 3;
                    break;

                case "Четверг":
                    pSchedule.dayWeek = 4;
                    break;

                case "Пятница":
                    pSchedule.dayWeek = 5;
                    break;
            }
            FrameApp.frmObj.Navigate(new pSchedule());
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            for (int w = 1; w < 6; w++)//week
            {
                for (int n = 1; n < 8; n++)//LessonNum
                {
                    List<int> teachers = ConnectHelper.entObj.Schedule.Where(s => s.WeekId == w && s.Num == n).Select(s => s.TeacherDiscipline.TeacherID).ToList();
                    List<int> cabinets = ConnectHelper.entObj.Schedule.Where(s => s.WeekId == w && s.Num == n).Select(s => s.CabinetNum).ToList();
                    List<int> teachers2 = teachers.Distinct().ToList();
                    List<int> cabinets2 = cabinets.Distinct().ToList();
                    if (cabinets.Count > teachers2.Count() || teachers.Count > cabinets2.Count())
                    {
                        (gWeek.Children[w - 1] as Rectangle).Visibility = Visibility.Visible;
                        (gWeek.Children[w - 1] as Rectangle).ToolTip = "Имеется конфликты с учителями или кабинетами";
                        (gWeek.Children[w + 4] as Button).ToolTip = "Имеется конфликты с учителями или кабинетами";
                        break;
                    }
                    else
                    {
                        (gWeek.Children[w - 1] as Rectangle).Visibility = Visibility.Hidden;
                        (gWeek.Children[w - 1] as Rectangle).ToolTip = null;
                        (gWeek.Children[w + 4] as Button).ToolTip = null;
                    }
                }
            }
            if (ConnectHelper.entObj.WarningLessons.Count() > 0)
                tbSvod.Text = "В этих классах необхадимо убрать указанное количество уроков: ";
            else
                tbSvod.Text = "";
            foreach (WarningLessons wl in ConnectHelper.entObj.WarningLessons)
            {
                tbSvod.Text += $"В {wl.Title} - {wl.CountLessons-wl.MaxHours} уроков (назначено {wl.CountLessons} из {wl.MaxHours}) ";
            }
        }
    }
}

﻿namespace SchedulingDesktop.Scripts
{
    class ConnectHelper
    {
        public static ScheduleEntities entObj;
    }
}

﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SchedulingDesktop.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulingDesktop.Pages.Tests
{
    
    [TestClass()]
    public class pWeeksTests
    {
        pWeeks pweek = new pWeeks();
        [TestMethod()]
        public void getWeekNumMondayTest()
        {
            Assert.AreEqual(pweek.getWeekNum("Понедельник"),1);
        }

        [TestMethod()]
        public void getWeekNumTuesdayest()
        {
            Assert.AreEqual(pweek.getWeekNum("Вторник"), 2);
        }

        [TestMethod()]
        public void getWeekNumWednessdayTest()
        {
            Assert.AreEqual(pweek.getWeekNum("Среда"), 3);
        }

        [TestMethod()]
        public void getWeekNumThirsdayTest()
        {
            Assert.AreEqual(pweek.getWeekNum("Четверг"), 4);
        }

        [TestMethod()]
        public void getWeekNumFridayTest()
        {
            Assert.AreEqual(pweek.getWeekNum("Пятница"), 5);
        }

        [TestMethod()]
        public void getWeekNumSaturdayTest()
        {
            Assert.AreEqual(pweek.getWeekNum("Суббота"), 0);
        }
    }
}